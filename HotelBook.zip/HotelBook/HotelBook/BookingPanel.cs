﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBook
{
    public partial class BookingPanel : Form
    {
        public BookingPanel()
        {
            InitializeComponent();
        }

        private void bookBookingPanel_Click(object sender, EventArgs e)
        {

        }

        private void backBookingPanel_Click(object sender, EventArgs e)
        {

        }
    }
}
