﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBook
{
    public partial class Home : Form
    {
        public Home()
        {
            InitializeComponent();
        }

        private void logout_Click(object sender, EventArgs e)
        {

        }

        private void control_Click(object sender, EventArgs e)
        {

        }

        private void booking_Click(object sender, EventArgs e)
        {

        }

        private void admin_Click(object sender, EventArgs e)
        {

        }

        private void register_Click(object sender, EventArgs e)
        {

        }
    }
}
