﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelBook
{
    public partial class AdminPanel : Form
    {
        public AdminPanel()
        {
            InitializeComponent();
        }

        private void addAdminPanel_Click(object sender, EventArgs e)
        {

        }

        private void removeAdminPanel_Click(object sender, EventArgs e)
        {

        }

        private void backAdminPanel_Click(object sender, EventArgs e)
        {

        }
    }
}
